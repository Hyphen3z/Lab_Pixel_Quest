License:

DO:

use the contents of this asset pack for personal and commercial works

modify the contents of this asset pack for the needs of your work

DO NOT:

resell the contents of this asset pack or the asset pack itself on their own

modify/combine/remix the contents of this asset pack for sale on their own or with any other asset packs

------------------

average animation size is about 32x32 pixels, but if you cut the images using the canvas size they will line up perfectly.

rat basic - 64x64 pixels
skeleton basic - 64x64
slime basic - 96x64

-------------------

v1.2

added jump animations to rat basic

adjusted canvas sizes to better center the characters
